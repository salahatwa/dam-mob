export class Customer {
  id?: string;
  name?: string;
  lastname?: string;
  address?: string;
  phone?: string;
  state?: string;
  email?: string;
  index?: number;
  image?: string;
  action?: string;

}
