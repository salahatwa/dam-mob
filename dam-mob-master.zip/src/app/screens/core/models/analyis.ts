import { Product } from './product';

//Shift + Ctrl + Alt + V)
export class Analyis {
  categories?: number;
  customers?: number;
  invoices?: number;
  products?:Product[];
}