export interface Menu {
    id: number;
    label: string;
    image: string;
    active: boolean;
    route: string;
}