import { NgModule } from '@angular/core';


import { LoginPageRoutingModule } from './login-routing.module';

import { HttpClient } from '@angular/common/http';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { SharedModule } from '../../shared/component/shared.module';
import { LoginPage } from './login.page';


export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/login/', '.json');
}

@NgModule({
  imports: [
    SharedModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: (HttpLoaderFactory),
        deps: [HttpClient]
      },
      isolate: false
    }),
    LoginPageRoutingModule
  ],
  exports: [TranslateModule],
  declarations: [LoginPage]
})
export class LoginPageModule { }
