import { NgModule } from '@angular/core';
import { GettingStartPage } from './getting-start.page';

import { SharedModule } from '../../shared/component/shared.module';
import { GettingStartPageRoutingModule } from './getting-start-routing.module';
import { TranslateModule } from '@ngx-translate/core';


@NgModule({
  imports: [
    SharedModule,
    TranslateModule,
    GettingStartPageRoutingModule
  ],
  declarations: [GettingStartPage]
})
export class GettingStartPageModule { }
