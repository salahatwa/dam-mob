import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/screens/shared/component/shared.module';
import { CustomerRoutingModule } from './customer-routing.module';
import { CustomerSelectDialogComponent } from './customer-select-dialog/customer-select-dialog.page';
import { CustomerComponent } from './customer.component';



@NgModule({
  declarations: [CustomerComponent, CustomerSelectDialogComponent],
  imports: [
    SharedModule,
    CustomerRoutingModule,
  ],
  entryComponents: [CustomerSelectDialogComponent],
  exports: [
    CustomerComponent,
    CustomerRoutingModule,
  ]
})
export class CustomerModule { }
