import { NgModule } from '@angular/core';


import { ListingPageRoutingModule } from './listing-routing.module';

import { HttpClient } from '@angular/common/http';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { SearchbarModule } from '../../component/searchbar/searchbar.module';
import { SharedModule } from '../../shared/component/shared.module';
import { ListingPage } from './listing.page';
import { MenuItemComponent } from './menu-item/menu-item.component';


export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/listing/', '.json');
}


@NgModule({
  imports: [
    SharedModule,
    ListingPageRoutingModule,
    SearchbarModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: (HttpLoaderFactory),
        deps: [HttpClient]
      },
      isolate: false
    }),
  ],
  declarations: [ListingPage, MenuItemComponent],
  exports: [
    // TranslateModule
    // ListingPageRoutingModule
  ]

})
export class ListingPageModule { }
