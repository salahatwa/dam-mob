import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params } from '@angular/router';
import { Customer } from '@core/models/customer';
import { Product } from '@core/models/product';
import { CustomerService } from '@core/services/customer.service';
import { ProductService } from '@core/services/product.service';
import { ToastController } from '@ionic/angular';
import { CommonService } from '@shared/services/common.service';
import { finalize } from 'rxjs/operators';

@Component({
  selector: 'app-product-operations',
  templateUrl: './product-operations.component.html',
  styleUrls: ['./product-operations.component.scss'],
})
export class ProductOperationsComponent implements OnInit {


  product: Product;
  productForm: FormGroup;
  constructor(private fb: FormBuilder, private toastCtrl: ToastController, private activatedRoute: ActivatedRoute, private common: CommonService, public productService: ProductService) {
    this.initForm({});
  }

  ngOnInit() {

    // this.id = this.activatedRoute.snapshot.paramMap.get('id');

    this.activatedRoute.params
      .subscribe(
        (params: Params) => {
          const id = params['id'];
          if (id.toUpperCase() != 'NEW')
            this.getCustomerDetails(id);

        }
      );



  }


  initForm(product: Product) {
    this.productForm = this.fb.group({
      'id': [product?.id],
      'name': [product?.name, [Validators.required, Validators.pattern('[0-9a-zA-Z\s\u0600-\u06FF]*')]],
      'location':[product?.location, [Validators.required, Validators.pattern('[0-9a-zA-Z\s\u0600-\u06FF]*')]],
      'price': [product?.price, [Validators.required]],
      'quantity': [product?.quantity, [Validators.required]],
      'code': [product?.code, []]
    });
  }


  get f() {
    return this.productForm.controls;
  }



  onSubmit() {
    this.common.showSpinner();

    let product = this.productForm.value;

    console.log(product);

    if (product.id == null)
      this.productService.insertProduct(product).pipe(finalize(() => {
        this.common.hideSpinner();
      })).subscribe(data => {
        this.presentToast();
        // this.alertService.success(this.translateService.instant('notify.success.add'), this.alert);
      }, err => {
        // this.alertService.error(err.message, this.alert);
      });

    else {
      this.productService.updateProduct(product).pipe(finalize(() => {
        this.common.hideSpinner();
      })).subscribe(data => {
        this.presentToast();
        // this.alertService.success(this.translateService.instant('notify.success.update'), this.alert);
      }, err => {
        // this.alertService.error(err.message, this.alert);
      });
    }
    // this.resetForm(customerForm);

  }


  getCustomerDetails(id) {
    this.common.showSpinner();
    this.productService.getProduct(id).pipe(finalize(() => {
      this.common.hideSpinner();
    })).subscribe(item => {
      console.log(item);
      this.initForm(item);
    }, err => {
     
    });
  }


  addItemToCart() {
    // const cartItem: CartItem = {
    //   id: this.food.id,
    //   name: this.food.title,
    //   price: this.food.price,
    //   image: this.food.image,
    //   quantity: 1
    // };

    // this.cartService.addToCart(cartItem);

    this.presentToast();
  }

  async presentToast() {
    const toast = await this.toastCtrl.create({
      message: 'Food added to the cart',
      mode: 'ios',
      duration: 1000,
      position: 'top'
    });
    toast.present();
  }


}
