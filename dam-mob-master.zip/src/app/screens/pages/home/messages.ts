// export const messages = {
//     en: {
//         "app": {
//             "dashboard": "Dashboard",
//             "profile": "Profile",
//             "create-invoice": "Create Invoice"
//          }
//     },
//     'ar': {
//         "app": {
//             "dashboard": "الرئيسية",
//             "profile": "الملف الشخصى",
//             "create-invoice": "إنشاء فاتورة"
//         }
//     }
//   }