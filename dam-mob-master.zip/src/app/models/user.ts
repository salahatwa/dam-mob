export interface IUser {
    email: string;
    name: string;
    id?: string;
    imageUrl?: string;
};
