export const environment = {
  production: true,
  api: 'https://dampharm-backend.herokuapp.com/api',
  unauth_api: 'https://dampharm-backend.herokuapp.com/unauth',
  googleClientid: '298206622192-ke686j1gaesu2t9fj72oad9tfep3esb9.apps.googleusercontent.com',
  };
